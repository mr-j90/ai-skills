---
name: prompt-cleanup
description: Analyze, refactor, and improve LLM prompts for clarity, reliability, and performance. Applies structural best practices — schema contracts, negative constraints, reasoning scaffolds, few-shot examples, and token efficiency. Use when user mentions "clean up this prompt", "improve my prompt", "refactor prompt", "prompt review", "optimize prompt", "fix my prompt", "prompt audit", pastes a prompt and asks to make it better, or wants help going from a rough draft prompt to a production-quality one.
---

# Prompt Cleanup

## Quick start

Take a raw/draft LLM prompt and produce a refactored version with a changelog explaining every improvement.

## Inputs

The user provides:
- **A prompt to clean up** — pasted inline, in a file, or described.
- **Optional context** — target model, use case, known failure modes, desired output format.

If context is missing, infer from the prompt content and state assumptions.

## Workflow

### 1. Analyze the original (internal — do not show raw)

Score the prompt across these dimensions internally:

| Dimension         | What to check                                                  |
|-------------------|----------------------------------------------------------------|
| **Clarity**       | Ambiguous instructions, vague targets, missing constraints     |
| **Structure**     | Missing I/O contracts, no section delimiters, wall-of-text     |
| **Specificity**   | No negative constraints, no examples, no format spec           |
| **Efficiency**    | Redundant instructions, filler phrases, token waste            |
| **Reliability**   | Underspecified edge cases, no reasoning scaffold, brittle format|
| **Persona/Role**  | Missing or generic role assignment, no expertise scoping       |

### 2. Present the diagnosis (1 turn)

Deliver a concise diagnostic summary:
- **Prompt type** — classify it: system prompt, user prompt, tool prompt, few-shot template, agent instruction, etc.
- **Top 3 issues** — the highest-impact problems, ranked by how much they hurt output quality.
- **Strengths** — what's already working (don't trash the whole thing).
- **Refactor plan** — numbered list of specific changes you will make.

Ask the user to confirm or adjust the plan before rewriting.

### 3. Refactor the prompt

Apply these techniques in priority order:

#### A. Structural framing
- Add XML tag delimiters for distinct sections (`<context>`, `<task>`, `<constraints>`, `<output_format>`)
- Separate system-level instructions from per-request content
- Add an explicit I/O contract if the prompt expects structured output

#### B. Negative constraints
- Convert vague positive instructions into specific DO / DO NOT pairs
- Add antipatterns for known failure modes (e.g., "DO NOT start with 'Sure, I'd be happy to...'")

#### C. Reasoning scaffold
- If the task is complex, add a `<thinking>` or `<scratchpad>` section with numbered reasoning steps
- Each step should name *what* to evaluate, not just "think step by step"

#### D. Few-shot examples
- If the prompt has zero examples, add 1–2 with input/output/rationale triples
- If examples exist but lack rationale, add `<why_this_is_good>` annotations

#### E. Persona sharpening
- Replace generic personas ("you are an expert") with scoped ones ("you are a senior .NET architect reviewing a PR for Azure cost implications")
- Add explicit focus/ignore directives tied to the persona

#### F. Token efficiency
- Remove filler ("Please kindly", "I'd like you to", "It would be great if")
- Collapse redundant instructions into single precise statements
- Move rarely-needed context into a separate `<reference>` block

### 4. Deliver the output

Produce **two artifacts**:

#### a. Refactored prompt
- Delivered as a fenced code block or file (`.md` or `.txt`)
- Ready to copy-paste into an API call, system prompt, or skill

#### b. Changelog
- Table format: `| # | Change | Why | Technique |`
- Every modification mapped to a named technique from the refactor list
- Enables the user to learn the pattern, not just consume the output

### 5. Optional: variant generation

If the user asks, produce 2–3 variants optimized for different tradeoffs:
- **Minimal** — fewest tokens, fastest, good for high-volume API calls
- **Robust** — maximum guardrails, best for production with untrusted input
- **Creative** — loosest constraints, best for brainstorming/exploration

## Behavioral rules

- Never rewrite without showing the diagnosis first — the user should understand *why* before seeing *what*.
- Preserve the user's intent and voice. Refactor structure and precision, don't impose a different personality.
- If the original prompt is already strong, say so. Don't manufacture changes for the sake of it.
- Explain techniques by name so the user builds prompt engineering intuition over time.
- If the prompt targets a specific model (GPT-4, Claude, Gemini, Llama), adapt recommendations to that model's known strengths and quirks.
- Keep the refactored prompt under 2x the original token count unless the user explicitly wants expansion.

## Technique reference (for changelog citations)

| Code | Technique                  |
|------|----------------------------|
| ST   | Structural framing (XML)   |
| NC   | Negative constraints       |
| RS   | Reasoning scaffold         |
| FS   | Few-shot examples          |
| PS   | Persona sharpening         |
| TE   | Token efficiency           |
| IO   | I/O contract definition    |
| PF   | Prefill / response priming |
| EC   | Edge case handling         |
| PD   | Progressive disclosure     |
