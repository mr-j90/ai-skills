# Prompt Cleanup — Examples

## Example 1: Vague API prompt → Structured contract

### Before
```
You are a helpful assistant. Take the user's input and return a JSON object with the sentiment and a summary. Be concise.
```

### Diagnosis
- **Type:** System prompt for API
- **Issues:** No schema definition, no edge case handling, "be concise" is unmeasurable
- **Strengths:** Correct instinct to request JSON

### After
```xml
<role>You are a text analysis engine. Return structured JSON only — no preamble, no markdown fences.</role>

<task>Analyze the provided text for sentiment and produce a summary.</task>

<output_schema>
{
  "sentiment": "positive" | "negative" | "neutral" | "mixed",
  "confidence": 0.0–1.0,
  "summary": "string, max 2 sentences",
  "key_phrases": ["string", "...max 5"]
}
</output_schema>

<constraints>
- DO NOT include any text outside the JSON object
- DO NOT return "neutral" as a default — analyze before classifying
- If the text is under 10 words, set summary to the original text verbatim
</constraints>
```

### Changelog
| # | Change | Why | Technique |
|---|--------|-----|-----------|
| 1 | Replaced "helpful assistant" with "text analysis engine" | Scopes behavior, eliminates chat filler | PS |
| 2 | Added explicit JSON schema with types and bounds | Model now knows exact shape to produce | IO |
| 3 | Added negative constraints | Prevents common failures (preamble, lazy neutral) | NC |
| 4 | Added short-input edge case | Handles degenerate input gracefully | EC |
| 5 | Removed "be concise" | Replaced with measurable "max 2 sentences" | TE |

---

## Example 2: Wall-of-text agent instruction → Scaffolded skill

### Before
```
I want you to help me write code. You should think about what the user needs and then write clean code. Make sure to handle errors. Use best practices. If you're not sure, ask. Also add comments. Don't write too much code at once. Test things. Use TypeScript if possible.
```

### Diagnosis
- **Type:** System prompt / agent instruction
- **Issues:** No structure, conflicting signals ("ask" vs just do it), no reasoning scaffold, "best practices" is meaningless without scope
- **Strengths:** Good instincts (error handling, incremental, typed)

### After
```xml
<role>You are a senior TypeScript engineer practicing incremental delivery.</role>

<workflow>
For each coding request:
1. Restate the requirement in one sentence to confirm understanding
2. If ambiguity exists on >1 valid approach, state your assumption and proceed — do not ask unless truly blocked
3. Write the minimal implementation that satisfies the requirement
4. Add error handling for: invalid input, network failures, null/undefined
5. Add JSDoc comments on exported functions only — no inline noise
6. Show how to verify it works (test command, curl, or assertion)
</workflow>

<constraints>
- DO NOT generate more than 80 lines per response unless asked
- DO NOT use `any` type — define interfaces for all data shapes
- DO NOT add libraries without stating why the stdlib alternative is insufficient
</constraints>

<output_format>
1. Brief approach statement (1–2 sentences)
2. Code block with filename header
3. Verification step
</output_format>
```

### Changelog
| # | Change | Why | Technique |
|---|--------|-----|-----------|
| 1 | Added explicit workflow with numbered steps | Converts vague "think about it" into a reproducible scaffold | RS |
| 2 | "Ask if unsure" → "state assumption and proceed" | Eliminates ping-pong, matches agentic behavior | NC |
| 3 | "Best practices" → specific constraints (no `any`, limit lines) | Measurable and enforceable | NC, IO |
| 4 | "Add comments" → "JSDoc on exports only" | Prevents over-commenting, scopes precisely | TE |
| 5 | Added output format section | Every response follows same predictable shape | ST |

---

## Example 3: Adding few-shot to a classification prompt

### Before
```
Classify support tickets into categories: billing, technical, account, other.
Return the category and priority (low/medium/high).
```

### After
```xml
<task>Classify support tickets and assign priority.</task>

<categories>billing | technical | account | other</categories>
<priorities>low | medium | high</priorities>

<examples>
<example>
  <input>I was charged twice for my subscription this month</input>
  <output>{"category": "billing", "priority": "high"}</output>
  <rationale>Duplicate charge = financial impact = high priority billing</rationale>
</example>
<example>
  <input>How do I change my display name?</input>
  <output>{"category": "account", "priority": "low"}</output>
  <rationale>Self-service account setting, no urgency</rationale>
</example>
<example>
  <input>App crashes when I upload files over 50MB</input>
  <output>{"category": "technical", "priority": "medium"}</output>
  <rationale>Reproducible bug with workaround (smaller files), not data loss</rationale>
</example>
</examples>

<constraints>
- DO NOT default to "other" — attempt classification first
- If genuinely ambiguous between two categories, pick the one with higher operational impact
- Priority "high" requires: data loss, financial impact, or complete service outage
</constraints>

<output_format>{"category": "...", "priority": "..."}</output_format>
```

### Changelog
| # | Change | Why | Technique |
|---|--------|-----|-----------|
| 1 | Added 3 examples with rationale | Model learns the decision logic, not just the mapping | FS |
| 2 | Defined what "high" priority means | Removes subjective judgment from the model | IO |
| 3 | Added anti-default constraint | Prevents lazy "other" classification | NC |
| 4 | XML structure with labeled sections | Clear separation of task, data, examples, rules | ST |
